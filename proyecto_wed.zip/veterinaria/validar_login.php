<?php
// Archivo: validar_login.php

// Incluir el archivo de configuración de la base de datos
include("config.php");

// Verificar si se recibieron datos del formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recibir los datos del formulario
    $nombre_usuario = $_POST['nombre_usuario'];
    $contraseña = $_POST['contraseña'];

    // Preparar la consulta SQL para validar el usuario y la contraseña
    $query = "SELECT * FROM tb_usuario2 WHERE nombre = ? AND contraseña = ?";
    
    // Preparar la declaración de consulta
    $stmt = mysqli_prepare($mysqli, $query);

    // Vincular los parámetros para la consulta
    mysqli_stmt_bind_param($stmt, "ss", $nombre_usuario, $contraseña);

    // Ejecutar la consulta
    mysqli_stmt_execute($stmt);

    // Obtener el resultado de la consulta
    $result = mysqli_stmt_get_result($stmt);

    // Contar el número de filas devueltas por la consulta
    $count = mysqli_num_rows($result);

    // Si se encontró un usuario con el nombre de usuario y contraseña proporcionados
    if ($count == 1) {
        // Liberar el resultado
        mysqli_free_result($result);

        // Cerrar la declaración
        mysqli_stmt_close($stmt);

        // Redirigir al usuario a la página de menú
        header("location: menu.php");
        exit(); // Terminar el script después de redirigir
    } else {
        // Si no se encontró el usuario, mostrar un mensaje de error
        echo "Nombre de usuario o contraseña incorrectos.";
    }
}
?>






 