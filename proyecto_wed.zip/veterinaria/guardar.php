<?php
// Archivo: guardar.php

// Incluir el archivo de configuración de la base de datos
include("config.php");

// Verificar si se recibieron datos del formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recibir los datos del formulario
    $nombre_usuario = $_POST['nombre_usuario'];
    $contraseña = $_POST['contraseña'];
    $correo = $_POST['correo'];

    // Preparar la consulta SQL para insertar el usuario en la base de datos
    $query = "INSERT INTO tb_usuario2 (nombre, contraseña, correo) VALUES ('$nombre_usuario', '$contraseña', '$correo')";

    // Ejecutar la consulta
    if (mysqli_query($mysqli, $query)) {
        echo '<script>alert("Usuario registrado correctamente."); window.location.href = "login.php";</script>';
    } else {
        echo "Error al registrar el usuario: " . mysqli_error($mysqli);
    }

    // Cerrar la conexión a la base de datos
    mysqli_close($mysqli);
}
?>




