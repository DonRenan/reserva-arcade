<?php
include("config.php");

// Consulta a la tabla de usuarios
$query_usuarios = "SELECT * FROM tb_usuario2";
$result_usuarios = mysqli_query($mysqli, $query_usuarios);

// Consulta a la tabla de ventas
$query_ventas = "SELECT * FROM tb_ventas";
$result_ventas = mysqli_query($mysqli, $query_ventas);

// Consulta a la tabla de reservas
$query_reservas = "SELECT * FROM tb_reserva";
$result_reservas = mysqli_query($mysqli, $query_reservas);

?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/mystyle1.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Áreas</title>
    <style>
        body {
            font-family: Verdana, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        .icon-bar {
            background-color: #333;
            overflow: hidden;
        }

        .icon-bar a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 20px;
            text-decoration: none;
            font-size: 17px;
        }

        .icon-bar a:hover {
            background-color: #ddd;
            color: black;
        }

        .container {
            width: 50%;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            margin-top: 50px;
        }

        h2 {
            color: #333;
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
</head>

<body>
    <!-- Menú de navegación -->
    <div class="icon-bar">
        <a href="menu.php"><i class="fa fa-registered"></i></a>
       </div>

    <h2>Áreas</h2>
    <hr>
    <div class="container">
        <!-- Tabla para mostrar las áreas de la base de datos -->
        <?php
        // Aquí iría el código PHP para obtener y mostrar los datos de la tabla
        ?>
        <table>
            <tr>
                <th>ID</th>
                <th>primer piso</th>
                <th>segundo piso</th>
            </tr>
            <!-- Ejemplo de fila de datos -->
            <tr>
                <td>1</td>
                <td>libre</td>
                <td>ocupado</td>
            </tr>
            <!-- Más filas de datos se agregarían dinámicamente con PHP -->
        </table>
    </div>
</body>

</html>
