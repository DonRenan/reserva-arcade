<?php
// Incluir el archivo de configuración de la base de datos
include("config.php");

// Inicializar las variables
$maquina = "";
$hora_inicio = "";
$hora_final = "";

// Verificar si se recibieron datos del formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recibir los datos del formulario
    if(isset($_POST['maquina']) && isset($_POST['hora_inicio']) && isset($_POST['hora_final'])) {
        $maquina = $_POST['maquina'];
        $hora_inicio = $_POST['hora_inicio'];
        $hora_final = $_POST['hora_final'];

        // Preparar la consulta SQL para seleccionar la reserva en la base de datos
        $query = "SELECT * FROM tb_reserva WHERE maquina = '$maquina' AND hora_inicio = '$hora_inicio' AND hora_final = '$hora_final'";

        // Ejecutar la consulta
        $result = mysqli_query($mysqli, $query);

        // Verificar si se encontraron resultados
        if ($result && mysqli_num_rows($result) > 0) {
            // Mostrar los detalles de la reserva
            while ($row = mysqli_fetch_assoc($result)) {
                $maquina = $row['maquina'];
                $hora_inicio = $row['hora_inicio'];
                $hora_final = $row['hora_final'];

                // Generar texto para el código QR
                $texto_qr = "Reserva realizada para la máquina $maquina desde las $hora_inicio hasta las $hora_final";

                // Nombre del archivo donde se guardará el código QR
                $nombre_archivo_qr = 'codigo_qr.png';

                // Generar código QR y guardarlo en un archivo
                QRcode::png($texto_qr, $nombre_archivo_qr, QR_ECLEVEL_L, 4);
            }
        } else {
            echo "No se encontró ninguna reserva con los datos proporcionados.";
        }

        // Cerrar la conexión a la base de datos
        mysqli_close($mysqli);
    } else {
        echo "No se recibieron todos los datos del formulario.";
    }
} else {
    echo "No se recibió el formulario correctamente.";
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalle de la Reserva</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 20px;
            text-align: center;
        }

        .container {
            width: 50%;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
        }

        h2 {
            color: #333;
            text-align: center;
        }

        p {
            color: #666;
            margin-bottom: 10px;
        }

        img {
            display: block;
            margin: 20px auto;
        }

        .icon-bar {
            position: fixed;
            top: 50%;
            transform: translateY(-50%);
            right: 20px;
        }

        .icon-bar a {
            display: block;
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px;
            margin-top: 10px;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .icon-bar a:hover {
            background-color: #666;
        }

        .reset-button {
            background-color: #f44336;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .reset-button:hover {
            background-color: #d32f2f;
        }
    </style>
</head>
<body>
<div class="icon-bar">
    <!-- Botón para regresar al menú principal -->
    <a href="menu.php">Menú Principal</a>
</div>

<div class="container">
    <!-- Aquí se mostrará la factura -->
    <h2>Detalle de la reserva</h2>
    <p>Máquina: <?php echo $maquina; ?></p>
    <p>Hora de inicio: <?php echo $hora_inicio; ?></p>
    <p>Hora final: <?php echo $hora_final; ?></p>
    <hr>
    <!-- Aquí se mostrará el código QR -->
    <img src="<?php echo $codigo_qr; ?>" alt="Código QR">
    <br>
    <!-- Botón para reiniciar la facturación -->
    <button class="reset-button" onclick="window.location.href = 'detalle.php'">Reiniciar Facturación</button>
</div>
</body>
</html>
