<?php
// Archivo: reservar_proyecto.php

// Incluir el archivo de configuración de la base de datos
include("config.php");

// Verificar si se recibieron datos del formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recibir los datos del formulario
    $maquina = $_POST['maquina'];
    $hora_inicio = $_POST['hora_inicio'];
    $hora_final = $_POST['hora_final'];

    // Preparar la consulta SQL para insertar la reserva en la base de datos
    $query = "INSERT INTO tb_reserva (maquina, hora_inicio, hora_final) VALUES ('$maquina', '$hora_inicio', '$hora_final')";

    // Ejecutar la consulta
    if (mysqli_query($mysqli, $query)) {
        echo '<script>alert("Reserva guardada correctamente."); window.location.href = "menu.php";</script>';
    } else {
        echo "Error al guardar la reserva: " . mysqli_error($mysqli);
    }

    // Cerrar la conexión a la base de datos
    mysqli_close($mysqli);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/mystyle1.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Reservar Proyecto</title>
    <style>
        /* Estilos personalizados */
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        .icon-bar {
            background-color: #333;
            overflow: hidden;
        }

        .icon-bar a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 20px;
            text-decoration: none;
            font-size: 17px;
        }

        .icon-bar a:hover {
            background-color: #ddd;
            color: black;
        }

        h2 {
            color: #333;
            text-align: center;
        }

        form {
            background: linear-gradient(to bottom right, #4CAF50, #008CBA);
            border-radius: 50%;
            padding: 40px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            width: 50%;
            margin: 0 auto;
            margin-top: 50px;
        }

        label {
            color: white;
            font-weight: bold;
        }

        input[type="text"],
        input[type="password"],
        input[type="email"],
        input[type="time"] {
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button[type="submit"] {
            width: 100%;
            background-color: #4CAF50;
            color: white;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <!-- Menú de navegación -->
    <div class="icon-bar">
        <a href="menu.php"><i class="fa fa-home"></i></a>
        <a href="detalle.php"><i class="fa fa-user"></i></a>
        <a href="areas.php"><i class="fa fa-coffee"></i></a>
    </div>

    <!-- Contenido del formulario de reserva de proyecto -->
    <h2>Reservar Proyecto</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
        <label for="maquina">Máquina:</label>
        <input type="text" id="maquina" name="maquina" required><br><br>
        
        <label for="hora_inicio">Hora de Inicio:</label>
        <input type="time" id="hora_inicio" name="hora_inicio" required><br><br>
        
        <label for="hora_final">Hora de Finalización:</label>
        <input type="time" id="hora_final" name="hora_final" required><br><br>
        
        <button type="submit">Reservar</button>
    </form>
</body>
</html>
